# Original-data URL discovery and acquisition (DOE / power–EV research)

**Thesis:** Engineering of Power–Electrified Transportation Interdependencies for Resilience (current V3).

## What is included
- `.github/skills/doe-power-ev-data-scraper/SKILL.md` — skill instructions, scientific gates and privacy/access constraints.
- `.github/skills/doe-power-ev-data-scraper/scripts/doe_scraper.py` — executable public metadata scraper, safe URL tester and small-file downloader.
- `.github/skills/doe-power-ev-data-scraper/tests/test_scraper.py` — 12 unit tests; all pass locally with mocked/sample inputs.
- `.github/workflows/doe-original-data-acquisition.yml` — GitHub Actions reproducibility workflow that runs real HTTP discovery, unit tests, bounded downloads and uploads the research results.

## Run locally or in Colab
```bash
pip install requests
python -m unittest discover -s .github/skills/doe-power-ev-data-scraper/tests -v
python .github/skills/doe-power-ev-data-scraper/scripts/doe_scraper.py --out doe_scraper_output --download-small --max-file-mb 5 --max-files 8 --max-api-calls 70
```

The scraper does not scrape sign-in pages, attempt authenticated bypass, or infer file URLs from titles. HTTP and checksum verification are different from validation of physical interdependencies. All evidence remains labeled according to sensor/experiment source.

## Source evidence (verified bibliographic pages)
- [DOE OE Power System Data Analytics](https://www.energy.gov/oe/power-system-data-analytics) — government overview and data gateways; not raw transformer/EVSE thermal CSV.
- [ORNL DOE EV Charging Data](https://openenergyhub.ornl.gov/explore/dataset/doe-ev-data-collection-charging-data/) — DOE EERE/OSTI DOI 10.15483/1989855; source origin may be charger, vehicle or submeter.
- [Iowa real distribution test networks](https://wzy.ece.iastate.edu/testsystem.html) — 240 and 296 bus systems, measured smart-meter aggregates and models.
- [TU Dortmund Zenodo records 14065331](https://zenodo.org/records/14065331) — lab synchronized grid/charger recordings plus 20.1 kB / 77 kB metadata CSVs; 207.7 MB/389.8 MB payloads excluded by default size cap.
- [ORNL CODAS EV router](https://openenergyhub.ornl.gov/explore/dataset/energy-router-electric-vehicle-dataset/) — testbed, not field validation.

## Caveats
- The DOE page is a resource directory, **not** an original synchronized transformer–EVSE thermal dataset.
- Successful HTTP 200 or file checksum confirms file transfer, **not** experiment relevance or field thermal causality.
- If source files require authentication, paywall or special access, record the restriction; request permission rather than bypassing it.
- Neither `G6` documented transformer–EVSE connectivity nor `G7` synchronized thermal coupling is satisfied by the initial discoveries.
